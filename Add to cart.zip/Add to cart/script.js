document.querySelectorAll('.add-to-cart').forEach(function (button) {
    button.addEventListener('click', function () {
        var cart = document.querySelector('.shopping-cart');
        var imgtodrag = this.parentNode.querySelector('img');
        if (imgtodrag) {
            var imgclone = imgtodrag.cloneNode(true);
            var imgRect = imgtodrag.getBoundingClientRect();
            imgclone.style.opacity = '0.5';
            imgclone.style.position = 'absolute';
            imgclone.style.height = '100px';
            imgclone.style.width = '100px';
            imgclone.style.zIndex = '100';
            imgclone.style.top = imgRect.top + 'px';
            imgclone.style.left = imgRect.left + 'px';
            document.body.appendChild(imgclone);

            var cartRect = cart.getBoundingClientRect();
            var dx = cartRect.left - imgRect.left + 10;
            var dy = cartRect.top - imgRect.top + 10;

            var startTime = null;
            function moveImage(timestamp) {
                if (!startTime) startTime = timestamp;
                var progress = timestamp - startTime;
                var easingProgress = progress / 1300; // 1000ms = 1s
                var newX = imgRect.left + dx * easingProgress;
                var newY = imgRect.top + dy * easingProgress;
                imgclone.style.left = newX + 'px';
                imgclone.style.top = newY + 'px';
                if (progress < 1000) {
                    window.requestAnimationFrame(moveImage);
                } else {
                    cart.classList.add('shake');
                    setTimeout(function () {
                        cart.classList.remove('shake');
                    }, 200);
                    imgclone.style.width = '0';
                    imgclone.style.height = '0';
                    setTimeout(function () {
                        imgclone.parentNode.removeChild(imgclone);
                    }, 1000);
                }
            }

            window.requestAnimationFrame(moveImage);
        }
    });
});
